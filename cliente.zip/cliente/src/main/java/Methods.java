import org.apache.hc.client5.http.classic.methods.HttpGet;
import org.apache.hc.client5.http.impl.classic.CloseableHttpClient;
import org.apache.hc.client5.http.impl.classic.CloseableHttpResponse;
import org.apache.hc.client5.http.impl.classic.HttpClients;
import org.apache.hc.core5.http.HttpEntity;
import org.apache.hc.core5.http.HttpResponse;
import org.apache.hc.core5.http.io.entity.EntityUtils;

import java.io.IOException;

public class Methods {

    CloseableHttpClient httpClient = HttpClients.createDefault();

    public void get (){

        HttpGet httpGet = new HttpGet("");

        CloseableHttpResponse response = null;
        try {
            response = httpClient.execute(httpGet);
            HttpEntity entity = response.getEntity();



            EntityUtils.consume(entity);
            response.close();
        } catch (IOException e) {
            e.printStackTrace();
        }


    }

    public void post (){

        HttpGet httpGet = new HttpGet("");

        try {
            HttpResponse httpResponse = httpClient.execute(httpGet);

        } catch (IOException e) {
            e.printStackTrace();
        }

    }

    public void delete (){


    }

    public void update (){


    }

}
