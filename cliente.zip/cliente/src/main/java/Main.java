import javafx.application.Application;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.layout.GridPane;
import javafx.stage.Stage;


public class Main extends Application{

    @Override
    public void start(Stage primaryStage) throws Exception {

        primaryStage.setTitle("Games Data");

        GridPane gp = new GridPane();

        Button bget = new Button("GET");
        Button bpost = new Button("POST");
        Button bupdate = new Button("UPDATE");
        Button bdelete = new Button("DELETE");

        gp.add(bget,5,5,1,1);
        gp.add(bpost,6,6,1,1);
        gp.add(bupdate,7,6,1,1);
        gp.add(bdelete,4,6,1,1);

        Scene scene = new Scene(gp,500,500);
        primaryStage.setScene(scene);
        primaryStage.show();


    }
    public static void main(String[] args) {
        // write your code here

        launch(args);

    }

}
